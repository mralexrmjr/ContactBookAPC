import sqlite3
import re

conn = sqlite3.connect('contacts.db')
cursor = conn.cursor()

cursor.execute('''
    CREATE TABLE IF NOT EXISTS ContactBook (
        ContactID INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT,
        last_name TEXT,
        phone INTEGER,
        email TEXT
    )
''')

conn.commit()
conn.close()


def data_exists():
    conn = sqlite3.connect('contacts.db')
    cursor = conn.cursor()
    cursor.execute('SELECT COUNT(*) FROM ContactBook')
    count = cursor.fetchone()[0]
    conn.close()
    return count > 0


def insert_contacts():
    conn = sqlite3.connect('contacts.db')
    cursor = conn.cursor()

    contacts_data = [
        ("Michael", "Rey", 9565641025, 'michael.rey1@gmail.com'),
        ("Max", "Holloway", 9563315755, "max.holloway@gmail.com"),
        ("Alexander", "Moreno", 9562660019, "alexander.moreno@gmail.com"),
        ("Ryan", "Hernandez", 9563351223, "ryan.hernandez@gmail.com"),
        ("Nick", "Gomez", 5122557874, "nick.gomez3@gmail.com"),
        ("Ashley", "Cruz", 9569230689, "ashley.cruz@gmail.com")
    ]

    cursor.executemany('INSERT INTO ContactBook (first_name, last_name, phone, email) VALUES (?, ?, ?, ?)',
                       contacts_data)
    print("Data inserted successfully.")

    conn.commit()
    conn.close()


if not data_exists():
    insert_contacts()

conn = sqlite3.connect('contacts.db')
cursor = conn.cursor()
cursor.execute('SELECT * FROM ContactBook')
rows = cursor.fetchall()

for row in rows:
    print(row)


def add_contact_to_db(first_name, last_name, phone, email):
    if not first_name or not last_name or not phone or not email:
        print("All fields (First Name, Last Name, Phone, Email) are mandatory.")
        return

    if not first_name.isalpha() or not last_name.isalpha():
        print("First Name and Last Name must contain only alphabetic characters.")
        return

    if not phone.isdigit():
        print("Phone number must be numeric.")
        return

    import re
    if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
        print("Invalid email format.")
        return

    conn = sqlite3.connect('contacts.db')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO ContactBook (first_name, last_name, phone, email) VALUES (?, ?, ?, ?)',
                   (first_name, last_name, phone, email))
    conn.commit()
    conn.close()


def list_all_contacts():
    conn = sqlite3.connect('contacts.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM Contacts')
    contacts = cursor.fetchall()
    conn.close()
    for contact in contacts:
        print(f'ID: {contact[0]}, First_Name: {contact[1]}, Last_Name: {contact[2]},  Phone: {contact[3]}, Email: '
              f'{contact[4]}')


def delete_contact_from_db(contact_id):
    conn = sqlite3.connect('contacts.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM ContactBook WHERE id = ?', (contact_id,))

    conn.commit()

    conn.close()


def update_contact_in_db(contact_id, new_phone):
    conn = sqlite3.connect('contacts.db')
    cursor = conn.cursor()
    cursor.execute('UPDATE ContactBook SET phone = ? WHERE id = ?', (new_phone, contact_id))
    conn.commit()
    conn.close()


while True:
    action = input('Select an action: (a) Add, (s) Search, (d) Delete, (u) Update, (l) List All, (q) Quit: ')

    if action == 'a':
        while True:
            first_name = input('Enter First Name: ')
            if not first_name:
                print('First Name is mandatory. Please try again.')
                continue
            elif not first_name.isalpha():
                print('First Name must contain only alphabetic characters. Please try again.')
                continue
            break

        while True:
            last_name = input('Enter Last Name: ')
            if not last_name:
                print('Last Name is mandatory. Please try again.')
                continue
            elif not last_name.isalpha():
                print('Last Name must contain only alphabetic characters. Please try again.')
                continue
            break

        while True:
            phone = input('Enter Phone Number: ')
            if not phone:
                print('Phone Number is mandatory. Please try again.')
                continue
            elif not phone.isdigit():
                print('Phone number must be numeric. Please try again.')
                continue
            break

        while True:
            email = input('Enter Email: ')
            if not email:
                print('Email is mandatory. Please try again.')
                continue
            elif not re.match(r"[^@]+@[^@]+\.[^@]+", email):
                print('Invalid email format. Please try again.')
                continue
            break

        try:
            add_contact_to_db(first_name, last_name, phone, email)
            print('Contact added successfully.')
        except Exception as e:
            print('An error occurred while adding the contact:', str(e))

    elif action == 's':
        search_term = input('Who is it you are looking for: ')
        conn = sqlite3.connect('contacts.db')
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM ContactBook WHERE first_name LIKE ? OR last_name LIKE ?',
                       ('%' + search_term + '%', '%' + search_term + '%'))

        results = cursor.fetchall()

        conn.close()

        if results:
            for row in results:
                print(f'ID: {row[0]}, First Name: {row[1]}, Last Name: {row[2]}, Phone: {row[3]}, Email: {row[4]}')

        else:
            print('No matching contacts found.')

    elif action == 'd':
        delete_term = input('Enter the name of the contact to delete: ')
        conn = sqlite3.connect('contacts.db')
        cursor = conn.cursor()
        cursor.execute('DELETE FROM ContactBook WHERE first_name = ?', (delete_term,))

        conn.commit()

        rows_affected = cursor.rowcount

        conn.close()

        if rows_affected > 0:
            print(f'Contact "{delete_term}" deleted successfully.')

        else:
            print(f'Contact "{delete_term}" not found.')

    elif action == 'u':

        while True:

            search_field = input('Enter the field to search for (first_name, last_name, phone, email): ')

            search_value = input(f'Enter the {search_field} to search for: ')

            if search_field in ['first_name', 'last_name'] and not search_value.isalpha():
                print(f"{search_field.capitalize()} must contain only alphabetic characters.")

                continue

            if search_field == 'phone' and not search_value.isdigit():
                print('Phone number must be numeric.')

                continue

            if search_field == 'email' and not re.match(r"[^@]+@[^@]+\.[^@]+", search_value):
                print('Invalid email format.')

                continue

            update_field = input('Enter the field to update (first_name, last_name, phone, email): ')

            new_value = input(f'Enter the new {update_field}: ')

            if update_field in ['first_name', 'last_name'] and not new_value.isalpha():
                print(f"{update_field.capitalize()} must contain only alphabetic characters.")

                continue

            if update_field == 'phone' and not new_value.isdigit():
                print('Phone number must be numeric.')

                continue

            if update_field == 'email' and not re.match(r"[^@]+@[^@]+\.[^@]+", new_value):
                print('Invalid email format.')

                continue

            conn = sqlite3.connect('contacts.db')

            cursor = conn.cursor()

            if update_field in ['first_name', 'last_name', 'phone', 'email']:

                cursor.execute(f'UPDATE ContactBook SET {update_field} = ? WHERE {search_field} = ?',
                               (new_value, search_value))

                print(f'Contacts with {search_field} "{search_value}" updated successfully.')

                conn.commit()

            else:

                print('Invalid field. Please try again.')

            conn.close()

            break

    elif action == 'l':
        conn = sqlite3.connect('contacts.db')
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM ContactBook')
        contacts = cursor.fetchall()
        conn.close()

        for contact in contacts:
            print(f'ID: {contact[0]}, First_Name: {contact[1]}, Last_Name: {contact[2]}, Phone: {contact[3]}, Email: '
                  f'{contact[4]}')

    elif action == 'q':
        break

    else:
        print('Invalid action. Please try again.')

print('Goodbye!')
